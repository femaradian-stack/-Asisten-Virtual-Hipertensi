# HyperCare — Asisten Virtual Hipertensi 🩺

> Dummy project asisten virtual berbasis AI untuk konsultasi dan pemantauan pasien hipertensi.

![HyperCare Preview](https://img.shields.io/badge/Status-Prototype-teal) ![HTML](https://img.shields.io/badge/HTML5-E34F26?logo=html5&logoColor=white) ![CSS](https://img.shields.io/badge/CSS3-1572B6?logo=css3&logoColor=white) ![JavaScript](https://img.shields.io/badge/JavaScript-F7DF1E?logo=javascript&logoColor=black)

---

## 📌 Tentang Proyek

HyperCare adalah prototype aplikasi web untuk asisten virtual konsultasi hipertensi. Proyek ini dibuat sebagai demonstrasi konsep penerapan AI percakapan dalam konteks kesehatan digital, khususnya untuk membantu tenaga kesehatan memantau dan berkomunikasi dengan pasien hipertensi.

---

## ✨ Fitur

- **Landing Page** — tampilan produk dengan statistik dan preview UI mobile
- **Manajemen Pasien** — sidebar daftar pasien dengan label risiko (tinggi/sedang/terkontrol)
- **Chat Interface** — percakapan dummy dengan riwayat konsultasi per pasien
- **Klasifikasi Otomatis** — deteksi input nilai tekanan darah (cth: `158/96`) dan klasifikasi kategori secara otomatis
- **Quick Chips** — shortcut pertanyaan umum
- **Panel Pasien** — data klinis dan riwayat tekanan darah
- **Responsive Design** — dioptimalkan untuk tampilan desktop

---

## 🚀 Cara Menjalankan

Cukup buka file `index.html` di browser — tidak perlu instalasi atau server tambahan.

```bash
# Clone atau download project
# Buka index.html di browser favorit Anda
open index.html
```

---

## 🗂 Struktur Proyek

```
hypertension-ai/
├── index.html    # Semua UI, logic, dan style dalam satu file
└── README.md     # Dokumentasi ini
```

---

## 💡 Cara Menggunakan Demo

1. Klik tombol **"Coba Demo"** di landing page
2. Pilih pasien dari sidebar kiri
3. Ketik pertanyaan bebas atau masukkan nilai tensi (cth: `150/95`)
4. Gunakan **Quick Chips** untuk pertanyaan umum
5. Lihat info pasien dan riwayat tensi di panel kanan

---

## 🔧 Stack Teknologi

- **HTML5 + CSS3 + Vanilla JavaScript** — tanpa framework
- **Google Fonts** (DM Serif Display + DM Sans)
- **Logika berbasis rule** untuk simulasi respons AI

---

## 📋 Disclaimer

Proyek ini adalah **prototype/dummy** untuk keperluan portofolio. Tidak dimaksudkan untuk penggunaan medis nyata. Semua data pasien adalah fiktif.

---

*Dibuat sebagai bagian dari eksplorasi UI/UX aplikasi kesehatan digital.*
